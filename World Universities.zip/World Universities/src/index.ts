import '@k2oss/k2-broker-core';
import { onexecuteWorldUniversities, WorldUniversities } from "./so_WorldUniversities";


metadata = {
    systemName: "com.k2.WorldUniversities",
    displayName: "JSSP - WorldUniversities",
    description: "JSSP - WorldUniversities",
    "configuration": {
        "MSGraphAPIURL": {
            "displayName": "MS Graph API URL",
            "type": "string",
            "value": "https://graph.microsoft.com/v1.0/",
            "required": true
            
        },
        "K2BaseUrl": {
            "displayName": "K2 Base URL",
            "type": "string",
            "value": "http://universities.hipolabs.com/",
            "required": true
        },
        "DEBUG": {
            "displayName": "DEBUG",
            "type": "boolean",
            "value": true
        }
    }
};

ondescribe = async function ({ configuration }): Promise<void> {
    console.log("ondescribe");
    postSchema({
        objects: {   
            WorldUniversities
        }
    });
}

onexecute = async function ({ objectName, methodName, parameters, properties, configuration}): Promise<void> {
    switch (objectName) {
            case "WorldUniversities":await onexecuteWorldUniversities(methodName, properties, parameters, configuration); break;
        default: throw new Error("The object " + objectName + " is not supported.");
    }
}