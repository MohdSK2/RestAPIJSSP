import "@k2oss/k2-broker-core";
import { ConsoleError,ConsoleLog, POSTxhr,Getxhr,DELETExhr, flattenProperties } from "./common";
import "core-js/modules/es.array-buffer.constructor"

export var WorldUniversities = {
    displayName: "World Universities",
    description: "Return a list of universities of a given country",
    properties: {     
        "domains": {
            "displayName": "domains",
            "type": "string",
            "description": "domains"
        },
        "web_pages": {
            "displayName": "Web Pages",
            "type": "string",
            "description": "Web Pages"
        },
        "name": {
            "displayName": "University Name",
            "type": "string",
            "description": "University Name"
        },
        "alpha_two_code": {
            "displayName": "alpha_two_code",
            "type": "string",
        },
        "state-province": {
            "displayName": "state-province",
            "type": "string",
            "description": "state-province"
        },
        "country": {
            "displayName": "country",
            "type": "string",
            "description": "country"
        },
        "countryInput": {
            "displayName": "countryInput",
            "type": "string",
            "description": "Enter country name"
        }
    },
    methods: {             
            "GetUniversitiesList": {
                "displayName": "Get Universities List",
                "type":"list",
                "inputs": ["countryInput"],
                "requiredInputs": ["countryInput"],
                "outputs": ["domains","web_pages","name","alpha_two_code","state-province","country"]
            }
        }
       
} as ServiceObject;

export async function onexecuteWorldUniversities(methodName: string, properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    switch (methodName) {
        case "GetUniversitiesList": await onexecuteGetUniversitiesList(properties, parameters, configuration); break;
        default: throw new Error(`The method ${methodName} is not supported.`);
    }
}


//Get all users from AAD
export async function onexecuteGetUniversitiesList(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            let responseData = {};
            let returnArray = [];

            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                        if (responseObj.length > 0)
                        {
                            postResult(responseObj);
                            // for (var i = 0; i < responseObj.length; i++) {
                            //     responseData = {
                            //         "domains": responseObj[i].domains[0],
                            //         "web_pages": responseObj[i].web_pages[0],
                            //         "name": responseObj[i].name,
                            //         "alpha_two_code": responseObj[i].alpha_two_code,
                            //         "state-province": responseObj[i]["state-province"],
                            //         "country": responseObj[i].country
                            //     }

                            //     returnArray.push(responseData);

                            // }
                        }
                        
                        //console.log(returnArray);
                        //postResult(returnArray);
                        

                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"WorldUniversities.onexecuteGetUniversitiesList",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
            if(properties["countryInput"] as string!=='' && properties["countryInput"] !== undefined && properties["countryInput"] !== null)
            {
                url = `${configuration["K2BaseUrl"]}search?country=${properties["countryInput"]}`;
            }
            else
            {
                //Get all users if no filter is specified
                url = `${configuration["K2BaseUrl"]}search?country=${properties["countryInput"]}`;   
            }

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"WorldUniversities.onexecuteGetUniversitiesList",configuration);
                reject(e);
            }    
        });
}