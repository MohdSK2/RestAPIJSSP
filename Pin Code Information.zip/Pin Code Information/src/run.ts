import '@k2oss/k2-broker-core';
import './index.ts';

function mock(name: string, value: any) {
    global[name] = value;
}

// This value is obfuscated on purpose. Replace with a valid OAuth token to run
let OAuthToken = "eyJ0eXAiOiJKV1QiLCJub25jZSI6Im5DTHM1MXJrazUwYjdITlgwaUY0dVgwVEZBYWplRktTQmlhVkotV0wxZnciLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC81NWFiOWU0ZS1lZTA4LTRhYzAtOGEyYy0xN2RiZWE4NGQ3ZjkvIiwiaWF0IjoxNjI0ODcxOTc1LCJuYmYiOjE2MjQ4NzE5NzUsImV4cCI6MTYyNDg3NTg3NSwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iLCJ1cm46bWljcm9zb2Z0OnJlcTEiLCJ1cm46bWljcm9zb2Z0OnJlcTIiLCJ1cm46bWljcm9zb2Z0OnJlcTMiLCJjMSIsImMyIiwiYzMiLCJjNCIsImM1IiwiYzYiLCJjNyIsImM4IiwiYzkiLCJjMTAiLCJjMTEiLCJjMTIiLCJjMTMiLCJjMTQiLCJjMTUiLCJjMTYiLCJjMTciLCJjMTgiLCJjMTkiLCJjMjAiLCJjMjEiLCJjMjIiLCJjMjMiLCJjMjQiLCJjMjUiXSwiYWlvIjoiQVVRQXUvOFRBQUFBTlZCU0lvTzVkN0pHdTZ3ZGs1SndHSlZnYlJWLzZkQU5Pd3NkL3BXU0szK2MrWVZsS2QxZi9WWjMySEZwYjc2NXVYRTZXUHFIZm54bDk1N2lSNml5bVE9PSIsImFtciI6WyJwd2QiLCJtZmEiXSwiYXBwX2Rpc3BsYXluYW1lIjoiR3JhcGggZXhwbG9yZXIgKG9mZmljaWFsIHNpdGUpIiwiYXBwaWQiOiJkZThiYzhiNS1kOWY5LTQ4YjEtYThhZC1iNzQ4ZGE3MjUwNjQiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IlN0YWxiZXJnIiwiZ2l2ZW5fbmFtZSI6Ik5pY2hvbGFzIiwiaWR0eXAiOiJ1c2VyIiwiaXBhZGRyIjoiODAuMTk1LjkyLjQwIiwibmFtZSI6Ik5pY2hvbGFzIFN0YWxiZXJnIiwib2lkIjoiNDM0YTY0ZDgtZTBhOC00NzNlLWFiYTUtOGY2OTg1NzgxMzJjIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTMxNDQyMDc4NjAtNDk4OTk5NDk0LTIzNzAyMTgxNDktMTEyNSIsInBsYXRmIjoiMyIsInB1aWQiOiIxMDAzN0ZGRUE0RkY1Qzg5IiwicmgiOiIwLkFUQUFUcDZyVlFqdXdFcUtMQmZiNm9UWC1iWElpOTc1MmJGSXFLMjNTTnB5VUdRd0FLYy4iLCJzY3AiOiJBdWRpdExvZy5SZWFkLkFsbCBEaXJlY3RvcnkuQWNjZXNzQXNVc2VyLkFsbCBEaXJlY3RvcnkuUmVhZC5BbGwgb3BlbmlkIHByb2ZpbGUgVXNlci5SZWFkIGVtYWlsIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoiU3BzY2JYQ2c1a0hURHIwWGlfalNkcGhib1dGQlhaNDBaWktpdnVDd05tVSIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJFVSIsInRpZCI6IjU1YWI5ZTRlLWVlMDgtNGFjMC04YTJjLTE3ZGJlYTg0ZDdmOSIsInVuaXF1ZV9uYW1lIjoiTmljaG9sYXNAc2VjdXJlZmxvdy5jby51ayIsInVwbiI6Ik5pY2hvbGFzQHNlY3VyZWZsb3cuY28udWsiLCJ1dGkiOiIxcDRpTlVwNkZVaVhOR3ZyeGs4MUFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyI2MmU5MDM5NC02OWY1LTQyMzctOTE5MC0wMTIxNzcxNDVlMTAiLCJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX3N0Ijp7InN1YiI6ImtZMUo4M214UXZyMlJoZHZmLUFtN1QwZWtzd2ZwZ1Bfei1LZEhpNF85b3MifSwieG1zX3RjZHQiOjE1MDY1MTAwODJ9.bA6m_jihDoUdLnvlR2ogyyc__gSXYsIuXpHNgWkDAQfhvkIRhRoZyqidaBdjDzawfBdw9ll38-qc2-KgooqcSK85u3cvpHC_FN0-zAMIaqHAnhq2ATqVKn75NDLYyy8fYGm87U35UUbMPiAqNnSLbp8uX5PxSlq7z8aiT09Xh2htVjQsAtMxziCr-C3HwHkqOZvKXXM9A04TgQaBNqxI4JYCDTCGi8K5gW323CfcYVeJ0y6-g2qnpA3eMC6613QJYJuFmYV8BTLKWR4jAM9E4mh8IZ3DL_X0TG5dXE7q9L5m8j9-4FqXgJLqCK9QJmT5xgYlouyWKe1RYziDk1V1LQ";

let schema = null;
mock('postSchema', function (result: any) {
    schema = result;
    console.log("postSchema:");
    console.log(schema);
});

let result: any = null;
function pr(r: any) {
    result = r;
    console.log("postResult:")
    console.log(JSON.stringify(result));
}

mock('postResult', pr);

let xhr: { [key: string]: any } = null;
class XHR {
    public onreadystatechange: () => void;
    public readyState: number;
    public status: number;
    public responseText: string;
    public withCredentials: boolean

    private recorder: { [key: string]: any };

    constructor() {
        xhr = this.recorder = {};
        this.recorder.headers = {};
    }

    open(method: string, url: string) {
        this.recorder.opened = { method, url };
    }

    setRequestHeader(key: string, value: string) {
        this.recorder.headers[key] = value;
        console.log("setRequestHeader: " + key + "=" + value);
    }

    send(payload) {
        const request = require('request')
        if (this.withCredentials) {
            this.setRequestHeader("Authorization", "Bearer " + OAuthToken);
        }
        
        const options = {
            method: this.recorder.opened.method,
            url: this.recorder.opened.url,
            headers: this.recorder.headers,
            body: payload,
            strictSSL: false
        };
        console.log("URL: " + options.method + " " + options.url);
        console.log("BODY: " + options.body);
        let promise = new Promise((resolve,reject) => {
            try {
                request(options, (error, res, body) => {
                    if (error) {
                        console.error("error inside request:" + error)
                        return
                    }
                    this.responseText = body;
                    this.readyState = 4;
                    this.status = res.statusCode;
                    this.onreadystatechange();
                    resolve(body)
                   // delete this.responseText;
                });                
            }
            catch(err) {
                console.log("error ouside request " + err);
                reject()
            }
        }).catch((errr) => {
            console.log("Promise error:" + errr);
        });
    }
}

mock('XMLHttpRequest', XHR);


onexecute({
    objectName: 'PinCodeInformation',
    methodName: 'GetPinCodeInformation',
    parameters: {},
    properties: {"country abbreviation":"IN","post code":"110034"},            
    configuration: { "K2BaseUrl": "https://api.zippopotam.us",
                        "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
                        "allowedDomains":"sap.com,nintex.com,k2.com" },
    schema: {}
  });

// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'AddUserToGroups',
//     parameters: {  },
//     properties: { "objectId":"9728fa4d-3b76-4f06-8271-32241a35d13e",
//                   "GroupIdArray":"[{\"objectId\": \"25fa68b4-aaf4-4e54-b0af-7acdaf706a0b\"}]"},
                  
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                      "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                      "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
//  });


// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'GetMyPhoto',
//     parameters: {  },
//     properties: { "objectId":"434a64d8-e0a8-473e-aba5-8f698578132c"},
                  
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                      "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                      "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
//  });
 
// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'RemoveUserFromGroup',
//     parameters: {  },
//     properties: { "objectId":"4b7c3d97-6c7b-4033-a918-9d84e786a6af",
//                   "groupId":"fc1d2f64-00a6-4830-a5fe-551e82836e96"},
                  
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                      "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                      "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
//  });

//  onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'ProvisionGuestUser',
//     parameters: {  },
//     properties: { "email":"nicholass@k2.com","firstName":"aaaa","lastName":"Stalberg (Testing)","welcomeMessage":"Welcome to SAP TSDE",
//                     "GroupIdArray":"[{\"objectId\": \"fc1d2f64-00a6-4830-a5fe-551e82836e96\"},{\"objectId\": \"2c6083d1-efd8-496b-aa27-ffbcbaab5ac3\"}]"},                  
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                      "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                      "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
//  });

// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'DeleteGuestUser',
//     parameters: {  },
//     properties: { "objectId":"f51adaa5-6a8b-4c5d-ad35-e0bc69baef70"},
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                      "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//     schema: {}
//  });

// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'PackGroupIdArray',
//     parameters: {"GroupId.String.Param":"[{\"objectId\":\"5bb8bc4d-ff85-4712-8cdd-45e3716d9d8e\"}]"},
//     properties: { "objectId":"5bb8bc4d-ff85-4712-8cdd-45e3716d9d8e"},
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/","MSGraphAPIURL":"https://graph.microsoft.com/v1.0/" },
//     schema: {}
//  });

// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'GetUsers',
//     parameters: {},
//     properties: {"search":""},            
//     configuration: { "K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                         "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                         "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
// //  });

// onexecute({
//     objectName: 'UserProvisioning',
//     methodName: 'GetGroupsForUser',
//     parameters: {},
//     properties: {"objectId":"33090edf-24ab-45c9-9994-9a212aefd6a4"},            
//     configuration: {"K2BaseUrl": "https://secureflow-dev.onk2.com/",
//                     "MSGraphAPIURL":"https://graph.microsoft.com/v1.0/",
//                     "allowedDomains":"sap.com,nintex.com,k2.com" },
//     schema: {}
//  });

 