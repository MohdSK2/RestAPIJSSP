import '@k2oss/k2-broker-core';
import { onexecutePinCodeInformation, PinCodeInformation } from "./so_PinCodeInformation";


metadata = {
    systemName: "com.k2.PinCodeInformation",
    displayName: "JSSP - PinCodeInformation",
    description: "JSSP - PinCodeInformation",
    "configuration": {
        "MSGraphAPIURL": {
            "displayName": "MS Graph API URL",
            "type": "string",
            "value": "https://graph.microsoft.com/v1.0/",
            "required": true
            
        },
        "K2BaseUrl": {
            "displayName": "K2 Base URL",
            "type": "string",
            "value": "https://api.zippopotam.us",
            "required": true
        },
        "DEBUG": {
            "displayName": "DEBUG",
            "type": "boolean",
            "value": true
        }
    }
};

ondescribe = async function ({ configuration }): Promise<void> {
    console.log("ondescribe");
    postSchema({
        objects: {   
            PinCodeInformation
        }
    });
}

onexecute = async function ({ objectName, methodName, parameters, properties, configuration}): Promise<void> {
    switch (objectName) {
            case "PinCodeInformation":await onexecutePinCodeInformation(methodName, properties, parameters, configuration); break;
        default: throw new Error("The object " + objectName + " is not supported.");
    }
}