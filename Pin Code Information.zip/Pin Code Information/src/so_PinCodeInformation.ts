import "@k2oss/k2-broker-core";
import { ConsoleError,ConsoleLog, POSTxhr,Getxhr,DELETExhr, flattenProperties } from "./common";
import "core-js/modules/es.array-buffer.constructor"

export var PinCodeInformation = {
    displayName: "Pin Code Information",
    description: "Return details of the given country and pincode",
    properties: {     
        "post code": {
            "displayName": "Post Code",
            "type": "string",
            "description": "Post Code"
        },
        "country": {
            "displayName": "country",
            "type": "string",
            "description": "country"
        },
        "country abbreviation": {
            "displayName": "country abbreviation",
            "type": "string",
            "description": "country abbreviation"
        },
        "place name": {
            "displayName": "place name",
            "type": "string",
            "description":"place name"
        },
        "longitude": {
            "displayName": "longitude",
            "type": "string",
            "description": "longitude"
        },
        "state": {
            "displayName": "state",
            "type": "string",
            "description": "state"
        },
        "state abbreviation": {
            "displayName": "state abbreviation",
            "type": "string",
            "description": "state abbreviation"
        },
        "latitude": {
            "displayName": "latitude",
            "type": "string",
            "description": "latitude"
        }
    },
    methods: {             
            "GetPinCodeInformation": {
                "displayName": "Get Pin Code Information",
                "type":"list",
                "inputs": ["country abbreviation","post code"],
                "requiredInputs": ["country abbreviation","post code"],
                "outputs": ["country abbreviation","post code","country","place name","longitude","state","state abbreviation","latitude"]
            }
        }
       
} as ServiceObject;

export async function onexecutePinCodeInformation(methodName: string, properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    switch (methodName) {
        case "GetPinCodeInformation": await onexecuteGetPinCodeInformation(properties, parameters, configuration); break;
        default: throw new Error(`The method ${methodName} is not supported.`);
    }
}


//Get all users from AAD
export async function onexecuteGetPinCodeInformation(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            let responseData = {};
            let returnArray = [];

            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                        if (responseObj.places.length > 0)
                        {

                            for (var i = 0; i < responseObj.places.length; i++) {
                                responseData = {
                                    "post code": responseObj["post code"],
                                    "country": responseObj["country"],
                                    "country abbreviation": responseObj["country abbreviation"],
                                    "place name": responseObj.places[i]["place name"],
                                    "longitude": responseObj.places[i].longitude,
                                    "state": responseObj.places[i].state,
                                    "state abbreviation": responseObj.places[i]["state abbreviation"],
                                    "latitude": responseObj.places[i].latitude
                                }

                                returnArray.push(responseData);

                            }
                        }
                        
                        console.log(returnArray);
                        postResult(returnArray);
                        

                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"PinCodeInformation.onexecuteGetPinCodeInformation",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
            if(properties["country abbreviation"] as string!=='' && properties["country abbreviation"] !== undefined && properties["country abbreviation"] !== null)
            {
                url = `${configuration["K2BaseUrl"]}/${properties["country abbreviation"]}/${properties["post code"]}`;
            }
            else
            {
                //Get all users if no filter is specified
                url = `${configuration["K2BaseUrl"]}/${properties["country abbreviation"]}/${properties["post code"]}`;
            }

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"WorldUniversities.onexecuteGetPinCodeInformation",configuration);
                reject(e);
            }    
        });
}