import test from 'ava';
import '@k2oss/k2-broker-core/test-framework';
import './index';


function mock(name: string, value: any) {
    global[name] = value;
}

test('describe returns the hardcoded instance', async t => {
    let schema = null;
    mock('postSchema', function (result: any) {
        schema = result;
    });

    await Promise.resolve<void>(ondescribe({
        configuration: {}
    }));

    t.deepEqual(schema, {
        objects: {
            "worktype": {
                displayName: "WorkType",
                description: "WorkType in sap-tsde",
                properties: {
                    "systemName": { displayName: "SystemName", type: "string" },
                    "name": { displayName: "Name", type: "string" },
                    "description": { displayName: "Description", type: "string" },
                    "icon": { displayName: "Icon", type: "string" },
                    "isActive": { displayName: "Active", type: "boolean" },
                    "isAbstract": { displayName: "Abstract", type: "boolean" },
                    "isCoreType": { displayName: "CoreType", type: "boolean" },
                    "systemNamePath": { displayName: "SystemName Path", type: "string" },
                    "parentSystemName": { displayName: "Parent SystemName", type: "string" },
                    "hasDerivedTypes": { displayName: "Has DerivedTypes", type: "boolean" }
                },
                methods: {
                    "list": { displayName: "List", type: "list", outputs: ["systemName", "name", "description", "icon", "isActive", "isAbstract", "isCoreType", "systemNamePath", "parentSystemName", "hasDerivedTypes"] }
                }
            },
            "sow": {
                displayName: "Statement of Work",
                description: "Statement of Work in sap-tsde",
                properties: {
                    "id": { displayName: "Id", type: "string" },
                    "reference": { displayName: "Reference", type: "string" },
                    "title": { displayName: "Title", type: "string" },
                    "description": { displayName: "Description", type: "string" },
                },
                methods: {
                    "list": { displayName: "List", type: "list", outputs: ["id", "reference", "title", "description"] }
                }
            }
        }
    });

    t.pass();
});


test.serial('execute with unsupported object and methods', async t => {
    let error = await t.throwsAsync(Promise.resolve<void>(onexecute({
        objectName: 'test1',
        methodName: 'unused',
        parameters: {},
        properties: {},
        configuration: {},
        schema: {}
    })));
    t.deepEqual(error.message, 'The object test1 is not supported.');
    error = await t.throwsAsync(Promise.resolve<void>(onexecute({
        objectName: 'worktype',
        methodName: 'unused',
        parameters: {},
        properties: {},
        configuration: {},
        schema: {}
    })));
    t.deepEqual(error.message, 'The method unused is not supported.');
    error = await t.throwsAsync(Promise.resolve<void>(onexecute({
        objectName: 'sow',
        methodName: 'unused',
        parameters: {},
        properties: {},
        configuration: {},
        schema: {}
    })));
    t.deepEqual(error.message, 'The method unused is not supported.');
    t.pass();
});

test.serial('execute executexhr expect error code', async t => {
    let xhr: { [key: string]: any } = null;
    class XHR1 {
        public onreadystatechange: () => void;
        public readyState: number;
        public status: number;
        public statusText: string;
        public responseText: string;
        private recorder: { [key: string]: any };

        constructor() {
            xhr = this.recorder = {};
            this.recorder.headers = {};
        }

        open(method: string, url: string) {
            this.recorder.opened = { method, url };
        }

        setRequestHeader(key: string, value: string) {
            this.recorder.headers[key] = value;
        }

        send() {
            queueMicrotask(() => {
                this.readyState = 3;
                this.onreadystatechange();
                this.readyState = 4;
                this.status = 500;
                this.statusText = "because";
                //this.responseText = JSON.stringify({ userName: 'wendy', learnerPK: 'e35935ac-006c-4d5f-bb34-17246220b06b' });//worktypelist
                this.onreadystatechange();
                delete this.responseText;
            });
        }
    }

    mock('XMLHttpRequest', XHR1);

    let error = await t.throwsAsync(Promise.resolve<void>(onexecute({
        objectName: 'worktype',
        methodName: 'list',
        parameters: {},
        properties: {},
        configuration: { 'ServiceURL': 'https://kdo.sap-tsde.co.uk/api/' },
        schema: {}
    })));

    t.deepEqual(error.message, 'Failed with status 500 statustext: because');

    t.pass();
});

test.serial('execute executexhr onerror', async t => {
    let xhr: { [key: string]: any } = null;
    class XHR1 {
        public onreadystatechange: () => void;
        public onerror: () => void;
        public readyState: number;
        public status: number;
        public statusText: string;
        public responseText: string;
        private recorder: { [key: string]: any };

        constructor() {
            xhr = this.recorder = {};
            this.recorder.headers = {};
        }

        open(method: string, url: string) {
            this.recorder.opened = { method, url };
        }

        setRequestHeader(key: string, value: string) {
            this.recorder.headers[key] = value;
        }

        send() {
            queueMicrotask(() => {
                this.status = 401;
                this.onerror();
            });
        }
    }

    mock('XMLHttpRequest', XHR1);

    let error = await t.throwsAsync(Promise.resolve<void>(onexecute({
        objectName: 'worktype',
        methodName: 'list',
        parameters: {},
        properties: {},
        configuration: { 'ServiceURL': 'https://kdo.sap-tsde.co.uk/api/' },
        schema: {}
    })));

    t.deepEqual(error.message, 'Failed with status 401');

    t.pass();
});