import "@k2oss/k2-broker-core";
import { ConsoleError,ConsoleLog, POSTxhr,Getxhr,DELETExhr, flattenProperties } from "./common";
import "core-js/modules/es.array-buffer.constructor"

export var RandomImages = {
    displayName: "Random Images",
    description: "Return random images",
    properties: {     
        "id": {
            "displayName": "id",
            "type": "string",
            "description": "id"
        },
        "author": {
            "displayName": "author",
            "type": "string",
            "description": "author"
        },
        "width": {
            "displayName": "width",
            "type": "number",
            "description": "width"
        },
        "height": {
            "displayName": "height",
            "type": "number",
            "description":"name"
        },
        "url": {
            "displayName": "url",
            "type": "string",
            "description": "url"
        },
        "download_url": {
            "displayName": "download_url",
            "type": "string",
            "description": "download_url"
        }
    },
    methods: {             
            "GetImages": {
                "displayName": "Get Images",
                "type":"list",
                "inputs": [],
                "outputs": ["id","author","width","height","url","download_url"]
            },
            "GetImage": {
                "displayName": "Get Image",
                "type":"read",
                "inputs": ["id"],
                "requiredInputs": ["id"],
                "outputs": ["id","author","width","height","url","download_url"]
            }
        }
       
} as ServiceObject;

export async function onexecuteRandomImages(methodName: string, properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    switch (methodName) {
        case "GetImages": await onexecuteGetImages(properties, parameters, configuration); break;
        case "GetImage": await onexecuteGetImage(properties, parameters, configuration); break;
        default: throw new Error(`The method ${methodName} is not supported.`);
    }
}


//Get all users from AAD
export async function onexecuteGetImages(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            let responseData = {};
            let returnArray = [];

            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);
                        // if (responseObj.length > 0)
                        // {

                        //     for (var i = 0; i < responseObj.length; i++) {
                        //         responseData = {
                        //             "id": responseObj[i].id,
                        //             "author": responseObj[i].author,
                        //             "width": responseObj[i].width,
                        //             "height": responseObj[i].height,
                        //             "url": responseObj[i].url,
                        //             "download_url": responseObj[i].download_url
                        //         }

                        //         returnArray.push(responseData);

                        //     }
                        // }
                        
                        responseObj.forEach(element => {
                            // responseData = {
                            //     "id": element.id,
                            //     "author": element.author,
                            //     "width": element.width,
                            //     "height": element.height,
                            //     "url": element.url,
                            //     "download_url": element.download_url
                            // }
                            
                            returnArray.push(element.id, element.author, element.width, element.height, element.url, element.download_url);
                        });
                        console.log(returnArray);
                        postResult(returnArray);
                        

                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"RandomImages.onexecuteGetImages",configuration);
                        resolve();
                    }     
                }
            let url:string;
            
            url = `${configuration["K2BaseUrl"]}/v2/list`;

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"RandomImages.onexecuteGetImages",configuration);
                reject(e);
            }    
        });
}

export async function onexecuteGetImage(properties: SingleRecord, parameters: SingleRecord, configuration: SingleRecord): Promise<void> {
    return  new Promise<void>(async (resolve, reject) => {
        try {          
            let responseObj:any; 
            let responseData = {};

            var xhr = new XMLHttpRequest();
            let responseCallBack = (xhrObj) =>
                {
                    xhr =xhrObj;
                    if(xhr.status === 200)
                    {
                        responseObj = JSON.parse(xhr.responseText);

                        responseData = {
                            "id": responseObj.id,
                            "author": responseObj.author,
                            "width": responseObj.width,
                            "height": responseObj.height,
                            "url": responseObj.url,
                            "download_url": responseObj.download_url
                        }
                        
                        console.log(responseData);
                        postResult(responseData);
                        

                        resolve();
                        return;
                    }      
                    if(xhr.status === 400)
                    {
                        ConsoleError(responseObj.error.message,"RandomImages.onexecuteGetImage",configuration);
                        resolve();
                    }     
                }
            let url:string;
            let filter:string='';
            if(properties["id"] !== undefined && properties["id"] !== null)
            {
                url = `${configuration["K2BaseUrl"]}/id/${properties["id"]}/info`;
            }
            else
            {
                //Get all users if no filter is specified
                url = `${configuration["K2BaseUrl"]}/id/0/info`;
            }

            await Getxhr(configuration,"GET", url, responseCallBack);
                } 
        catch (e) {
                ConsoleError(`${e.message} \rError stack:${e.stack}`,"RandomImages.onexecuteGetImage",configuration);
                reject(e);
            }    
        });
}