import '@k2oss/k2-broker-core';
import { onexecuteRandomImages, RandomImages } from "./so_RandomImages";


metadata = {
    systemName: "com.k2.RandomImages",
    displayName: "JSSP - RandomImages",
    description: "JSSP - RandomImages",
    "configuration": {
        "MSGraphAPIURL": {
            "displayName": "MS Graph API URL",
            "type": "string",
            "value": "https://graph.microsoft.com/v1.0/",
            "required": true
            
        },
        "K2BaseUrl": {
            "displayName": "K2 Base URL",
            "type": "string",
            "value": "https://picsum.photos",
            "required": true
        },
        "DEBUG": {
            "displayName": "DEBUG",
            "type": "boolean",
            "value": true
        }
    }
};

ondescribe = async function ({ configuration }): Promise<void> {
    console.log("ondescribe");
    postSchema({
        objects: {   
            RandomImages
        }
    });
}

onexecute = async function ({ objectName, methodName, parameters, properties, configuration}): Promise<void> {
    switch (objectName) {
            case "RandomImages":await onexecuteRandomImages(methodName, properties, parameters, configuration); break;
        default: throw new Error("The object " + objectName + " is not supported.");
    }
}